from sqlalchemy.orm import Session
from App.Models.models import Address
from App.Schemas import schemas
from App.Log.logger import logger

def create_address(db: Session, address: schemas.AddressCreate):
    logger.info("Creating address in DB")
    obj = Address(**address.dict())
    db.add(obj)
    db.commit()
    db.refresh(obj)
    logger.info("Address created successfully")
    return obj

def get_all_addresses(db: Session):
    logger.info("Fetching all addresses")
    return db.query(Address).all()

def get_address(db: Session, address_id: int):
    logger.info(f"Fetching address with ID: {address_id}")
    return db.query(Address).filter(Address.id == address_id).first()

def update_address(db: Session, address_id: int, data: schemas.AddressUpdate):
    logger.info(f"Updating address with ID: {address_id}")
    obj = get_address(db, address_id)
    if not obj:
        return None

    for key, value in data.dict().items():
        setattr(obj, key, value)

    db.commit()
    db.refresh(obj)
    return obj

def delete_address(db: Session, address_id: int):
    obj = get_address(db, address_id)
    if obj:
        db.delete(obj)
        db.commit()
    return obj