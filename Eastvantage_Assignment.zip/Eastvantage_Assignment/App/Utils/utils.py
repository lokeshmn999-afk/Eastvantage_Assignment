
import os
from App.Log.logger import logger


def calculate_distance(lat1, lon1, lat2, lon2):
    logger.info(f"Calculating distance between ({lat1}, {lon1}) and ({lat2}, {lon2})")
    return ((lat2 - lat1) ** 2 + (lon2 - lon1) ** 2) ** 0.5
