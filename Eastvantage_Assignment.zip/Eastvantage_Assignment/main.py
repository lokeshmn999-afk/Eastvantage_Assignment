
import uvicorn
from fastapi import FastAPI, Depends, HTTPException
from sqlalchemy.orm import Session
from App.Database import database
from App.Models import models
from App.Schemas.schemas import AddressResponse, AddressCreate, AddressUpdate
from App.Service.crud import create_address, get_all_addresses, update_address, delete_address
from App.Utils.utils import calculate_distance
from App.Log.logger import logger

models.Base.metadata.create_all(bind=database.engine)

app = FastAPI(title="Address Book API")

def get_db():
    db = database.SessionLocal()
    try:
        yield db
    finally:
        db.close()


@app.post("/addresses", response_model=AddressResponse)
def create_address_route(address: AddressCreate, db: Session = Depends(get_db)):
    logger.info("Creating address")
    return create_address(db, address)


@app.get("/addresses", response_model=list[AddressResponse])
def get_addresses(db: Session = Depends(get_db)):
    return get_all_addresses(db)


@app.put("/addresses/{id}", response_model=AddressResponse)
def update(id: int, address: AddressUpdate, db: Session = Depends(get_db)):
    result = update_address(db, id, address)
    if not result:
        raise HTTPException(status_code=404, detail="Address not found")
    return result


@app.delete("/addresses/{id}")
def delete(id: int, db: Session = Depends(get_db)):
    result = delete_address(db, id)
    if not result:
        raise HTTPException(status_code=404, detail="Address not found")
    return {"message": "Deleted"}


@app.get("/addresses/nearby", response_model=list[AddressResponse])
def nearby(lat: float, lon: float, distance: float, db: Session = Depends(get_db)):
    addresses = get_all_addresses(db)

    result = []
    for addr in addresses:
        d = calculate_distance(lat, lon, addr.latitude, addr.longitude)
        if d <= distance:
            result.append(addr)
    return result


if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)